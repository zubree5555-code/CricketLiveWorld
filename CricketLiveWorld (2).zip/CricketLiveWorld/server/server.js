/* ============================================================
   CricketLive World — Backend API Proxy
   ------------------------------------------------------------
   This is the ONLY place your real cricket API key lives.
   The frontend (www/js/app.js) never sees it — it only talks
   to this server, which attaches the key server-side before
   forwarding the request to the real provider (CricAPI).

   Responsibilities:
   - Hold the API key securely (from environment variable)
   - Proxy requests to CricAPI
   - Cache responses briefly to reduce provider API usage
   - Rate-limit incoming requests (basic protection)
   - Never leak the provider's raw error payloads or the key
   ============================================================ */

require("dotenv").config();
const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;
const CRICKET_API_KEY = process.env.CRICKET_API_KEY;
const CRICKET_API_BASE_URL = process.env.CRICKET_API_BASE_URL || "https://api.cricapi.com/v1";

if (!CRICKET_API_KEY) {
  console.warn(
    "\n⚠️  CRICKET_API_KEY is not set.\n" +
    "   Copy .env.example to .env and add your real CricAPI key.\n" +
    "   Every request will fail with a clear error until you do.\n"
  );
}

app.use(cors()); // restrict this to your real app's origin(s) before going to production
app.use(express.json());

/* ---------- tiny in-memory cache (per endpoint+query) ---------- */
const CACHE_TTL_MS = 60 * 1000; // 60s — cricket data doesn't need to be fetched more often than this
const cache = new Map();
function cacheKey(path, query) { return path + "?" + new URLSearchParams(query).toString(); }

/* ---------- basic rate-limit protection (per IP) ---------- */
const RATE_LIMIT_WINDOW_MS = 60 * 1000;
const RATE_LIMIT_MAX = 60; // 60 requests/minute/IP to this backend
const rateBuckets = new Map();
function isRateLimited(ip) {
  const now = Date.now();
  const bucket = rateBuckets.get(ip) || [];
  const recent = bucket.filter(t => now - t < RATE_LIMIT_WINDOW_MS);
  recent.push(now);
  rateBuckets.set(ip, recent);
  return recent.length > RATE_LIMIT_MAX;
}

/* ---------- generic proxy helper ---------- */
async function proxyToCricAPI(res, endpoint, query, cacheable = true) {
  if (!CRICKET_API_KEY) {
    return res.status(500).json({ error: "Server is not configured with a CRICKET_API_KEY. See server/.env.example." });
  }

  const key = cacheKey(endpoint, query);
  if (cacheable) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.t < CACHE_TTL_MS) {
      return res.json(cached.data);
    }
  }

  const usp = new URLSearchParams({ apikey: CRICKET_API_KEY, ...query });
  const url = `${CRICKET_API_BASE_URL}/${endpoint}?${usp.toString()}`;

  let providerRes;
  try {
    providerRes = await fetch(url);
  } catch (e) {
    return res.status(502).json({ error: "Could not reach the cricket data provider." });
  }

  if (providerRes.status === 429) {
    return res.status(429).json({ error: "The cricket data provider's rate limit was hit. Try again shortly." });
  }
  if (!providerRes.ok) {
    return res.status(502).json({ error: `Cricket data provider returned status ${providerRes.status}.` });
  }

  let data;
  try {
    data = await providerRes.json();
  } catch (e) {
    return res.status(502).json({ error: "Cricket data provider returned an invalid response." });
  }

  if (data.status && data.status !== "success") {
    // Pass through the provider's own message (e.g. invalid key, bad id) without exposing internals
    return res.status(400).json({ error: data.info || data.status });
  }

  if (cacheable) cache.set(key, { t: Date.now(), data });
  res.json(data);
}

/* ---------- rate-limit middleware ---------- */
app.use("/api", (req, res, next) => {
  const ip = req.ip || req.connection.remoteAddress || "unknown";
  if (isRateLimited(ip)) {
    return res.status(429).json({ error: "Too many requests. Please slow down." });
  }
  next();
});

/* ============================================================
   ROUTES — one per screen's data need, mirroring CricAPI
   ============================================================ */

// Live + upcoming + completed matches (Home, Matches screens)
app.get("/api/current-matches", (req, res) => {
  proxyToCricAPI(res, "currentMatches", { offset: req.query.offset || 0 });
});

// Single match info (Match Detail → Overview)
app.get("/api/match-info", (req, res) => {
  if (!req.query.id) return res.status(400).json({ error: "Missing required 'id' query parameter." });
  proxyToCricAPI(res, "match_info", { id: req.query.id }, false); // live match info shouldn't be cached long
});

// Full scorecard (Match Detail → Scorecard)
app.get("/api/match-scorecard", (req, res) => {
  if (!req.query.id) return res.status(400).json({ error: "Missing required 'id' query parameter." });
  proxyToCricAPI(res, "match_scorecard", { id: req.query.id }, false);
});

// Series list / search (Series screen, Search)
app.get("/api/series", (req, res) => {
  const query = { offset: req.query.offset || 0 };
  if (req.query.search) query.search = req.query.search;
  proxyToCricAPI(res, "series", query);
});

// Single series info + points table + match list (Series Detail)
app.get("/api/series-info", (req, res) => {
  if (!req.query.id) return res.status(400).json({ error: "Missing required 'id' query parameter." });
  proxyToCricAPI(res, "series_info", { id: req.query.id });
});

// Player search (Players screen, Search)
app.get("/api/players", (req, res) => {
  const query = { offset: req.query.offset || 0 };
  if (req.query.search) query.search = req.query.search;
  proxyToCricAPI(res, "players", query);
});

// Single player profile + career stats (Player Detail)
app.get("/api/players-info", (req, res) => {
  if (!req.query.id) return res.status(400).json({ error: "Missing required 'id' query parameter." });
  proxyToCricAPI(res, "players_info", { id: req.query.id });
});

// Countries/teams list (Teams screen)
app.get("/api/countries", (req, res) => {
  proxyToCricAPI(res, "countries", {});
});

// Health check — useful to confirm the server is up and the key is configured
app.get("/api/health", (req, res) => {
  res.json({ ok: true, keyConfigured: !!CRICKET_API_KEY });
});

app.listen(PORT, () => {
  console.log(`CricketLive World backend running on http://localhost:${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/api/health`);
});
