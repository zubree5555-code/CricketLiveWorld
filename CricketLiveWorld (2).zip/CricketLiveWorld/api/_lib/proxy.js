/* ============================================================
   Shared helper used by every function in /api.
   Runs on Vercel's Node.js serverless runtime. The API key is
   read from process.env — set as an Environment Variable in
   the Vercel project dashboard, never committed to the repo
   and never sent to the browser.

   Note on caching: Vercel serverless functions are stateless
   between invocations (no shared memory like a normal server),
   so the in-memory cache here only helps within a single warm
   instance — it's a bonus, not a guarantee. That's expected and
   fine for this use case.
   ============================================================ */

const CRICKET_API_BASE_URL = process.env.CRICKET_API_BASE_URL || "https://api.cricapi.com/v1";
const CACHE_TTL_MS = 60 * 1000;
const cache = new Map();

function cacheKey(endpoint, query) {
  return endpoint + "?" + new URLSearchParams(query).toString();
}

async function proxyToCricAPI(res, endpoint, query, cacheable = true) {
  const CRICKET_API_KEY = process.env.CRICKET_API_KEY;

  if (!CRICKET_API_KEY) {
    res.status(500).json({ error: "Server is not configured with a CRICKET_API_KEY. Set it in the Vercel project's Environment Variables." });
    return;
  }

  const key = cacheKey(endpoint, query);
  if (cacheable) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.t < CACHE_TTL_MS) {
      res.status(200).json(cached.data);
      return;
    }
  }

  const usp = new URLSearchParams({ apikey: CRICKET_API_KEY, ...query });
  const url = `${CRICKET_API_BASE_URL}/${endpoint}?${usp.toString()}`;

  let providerRes;
  try {
    providerRes = await fetch(url);
  } catch (e) {
    res.status(502).json({ error: "Could not reach the cricket data provider." });
    return;
  }

  if (providerRes.status === 429) {
    res.status(429).json({ error: "The cricket data provider's rate limit was hit. Try again shortly." });
    return;
  }
  if (!providerRes.ok) {
    res.status(502).json({ error: `Cricket data provider returned status ${providerRes.status}.` });
    return;
  }

  let data;
  try {
    data = await providerRes.json();
  } catch (e) {
    res.status(502).json({ error: "Cricket data provider returned an invalid response." });
    return;
  }

  if (data.status && data.status !== "success") {
    res.status(400).json({ error: data.info || data.status });
    return;
  }

  if (cacheable) cache.set(key, { t: Date.now(), data });
  res.status(200).json(data);
}

// Very small per-instance rate limiter — same caveat as caching above
// (resets whenever Vercel spins up a fresh instance). It's a helpful
// backstop, not a substitute for the provider's own rate limit.
const RATE_LIMIT_WINDOW_MS = 60 * 1000;
const RATE_LIMIT_MAX = 60;
const rateBuckets = new Map();
function isRateLimited(ip) {
  const now = Date.now();
  const bucket = rateBuckets.get(ip) || [];
  const recent = bucket.filter(t => now - t < RATE_LIMIT_WINDOW_MS);
  recent.push(now);
  rateBuckets.set(ip, recent);
  return recent.length > RATE_LIMIT_MAX;
}

function setCors(res) {
  // Same-origin in production (frontend and /api are on the same Vercel domain),
  // kept permissive here so local testing against a deployed backend also works.
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
}

module.exports = { proxyToCricAPI, isRateLimited, setCors };
