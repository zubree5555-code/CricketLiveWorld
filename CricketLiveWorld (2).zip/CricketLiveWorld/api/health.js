module.exports = async (req, res) => {
  res.status(200).json({ ok: true, keyConfigured: !!process.env.CRICKET_API_KEY });
};
