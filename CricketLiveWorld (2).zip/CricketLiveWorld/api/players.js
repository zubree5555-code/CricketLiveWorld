const { proxyToCricAPI, isRateLimited, setCors } = require("./_lib/proxy");

module.exports = async (req, res) => {
  setCors(res);
  if (req.method === "OPTIONS") return res.status(200).end();
  const ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress || "unknown";
  if (isRateLimited(ip)) return res.status(429).json({ error: "Too many requests. Please slow down." });

  const query = { offset: req.query.offset || 0 };
  if (req.query.search) query.search = req.query.search;
  await proxyToCricAPI(res, "players", query);
};
