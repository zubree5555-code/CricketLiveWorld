const { proxyToCricAPI, isRateLimited, setCors } = require("./_lib/proxy");

module.exports = async (req, res) => {
  setCors(res);
  if (req.method === "OPTIONS") return res.status(200).end();
  const ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress || "unknown";
  if (isRateLimited(ip)) return res.status(429).json({ error: "Too many requests. Please slow down." });

  if (!req.query.id) return res.status(400).json({ error: "Missing required 'id' query parameter." });
  await proxyToCricAPI(res, "match_scorecard", { id: req.query.id }, false);
};
