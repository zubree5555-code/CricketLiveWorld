/* ============================================================
   API CONFIGURATION
   ------------------------------------------------------------
   This app NEVER talks to the cricket data provider directly,
   and NEVER holds an API key. Every request goes to this app's
   own backend, which holds the real key server-side and proxies
   the request. On Vercel, that backend is the /api serverless
   functions in this same project — same domain, so a relative
   path is all that's needed.

   - Deployed on Vercel (default): "/api" — works as-is, no edit needed.
   - Local testing with `vercel dev` (also serves /api on the same
     origin): "/api" still works unchanged.
   - Testing against the standalone Express server in /server instead:
       "http://localhost:3000/api"
   - Testing on a real Android device against a non-Vercel backend:
       "http://<your-computer's-LAN-IP>:3000/api"
   ============================================================ */
const CONFIG = {
  API_BASE_URL: "/api",
  CACHE_TTL_MS: 60 * 1000,
};

const APP_LOGO = "assets/logo.png";

/* ---------- tiny in-memory cache + fetch wrapper ---------- */
const _cache = new Map();
async function apiGet(endpoint, params = {}) {
  const usp = new URLSearchParams(params);
  const qs = usp.toString();
  const url = `${CONFIG.API_BASE_URL}/${endpoint}${qs ? "?" + qs : ""}`;
  const cached = _cache.get(url);
  if (cached && Date.now() - cached.t < CONFIG.CACHE_TTL_MS) return cached.data;

  let res;
  try {
    res = await fetch(url, { method: "GET" });
  } catch (e) {
    const err = new Error("NETWORK_ERROR"); err.code = "NETWORK_ERROR"; throw err;
  }
  if (res.status === 429) { const err = new Error("RATE_LIMIT"); err.code = "RATE_LIMIT"; throw err; }
  if (!res.ok) {
    let info = null;
    try { info = (await res.json()).error; } catch (e) {}
    const err = new Error("BAD_RESPONSE"); err.code = "BAD_RESPONSE"; err.info = info; throw err;
  }
  const data = await res.json();
  _cache.set(url, { t: Date.now(), data });
  return data;
}

const CricketAPI = {
  currentMatches: () => apiGet("current-matches"),
  matchInfo: (id) => apiGet("match-info", { id }),
  matchScorecard: (id) => apiGet("match-scorecard", { id }),
  series: (search = "") => apiGet("series", search ? { search } : {}),
  seriesInfo: (id) => apiGet("series-info", { id }),
  players: (search = "") => apiGet("players", search ? { search } : {}),
  playerInfo: (id) => apiGet("players-info", { id }),
  countries: () => apiGet("countries"),
};

/* ============================================================
   DATA MAPPING — normalises the provider's raw shape into what
   the UI needs. Nothing here invents values; if a field is
   missing from the API response, it is passed through as null
   and the UI shows an honest "not available" state.
   ============================================================ */
function mapMatch(raw) {
  const teams = raw.teams || [];
  const scoreOf = (name) => (raw.score || []).find(s => s.inning && s.inning.startsWith(name));
  const buildTeam = (name) => {
    const s = scoreOf(name);
    return { name, score: s ? s.r : null, wkts: s ? s.w : null, overs: s ? s.o : null };
  };
  return {
    id: raw.id,
    series: raw.name || raw.series_id || "Match",
    matchType: (raw.matchType || "").toUpperCase(),
    status: raw.status || null,
    venue: raw.venue || null,
    live: !!raw.matchStarted && !raw.matchEnded,
    matchStarted: !!raw.matchStarted,
    matchEnded: !!raw.matchEnded,
    t1: teams[0] ? buildTeam(teams[0]) : null,
    t2: teams[1] ? buildTeam(teams[1]) : null,
  };
}

/* ============================================================
   APP STATE
   ============================================================ */
const state = {
  screen: "home", theme: "dark",
  activeMatchId: null, activeMatchTab: "overview", activeSeriesId: null, activePlayerId: null, activeTeamName: null,
  matchFilter: "all", matchStatus: "live", searchQuery: "", teamSearchQuery: "", playerSearchQuery: "",
  favorites: new Map(), // key "type:id" -> { label, sub, screen, params } — enough to render/navigate without refetching
  user: null, // { name, email } — kept only in memory for this session; not sent anywhere (no backend auth wired up yet)
  authMode: "login",
  authError: "",
  cache: {}, // last-fetched lists for this session, so switching tabs doesn't always refetch
};
let screenStack = ["home"];

function el(tag, attrs = {}, children = []) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") e.className = v;
    else if (k.startsWith("on") && typeof v === "function") e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  }
  (Array.isArray(children) ? children : [children]).forEach(c => { if (c != null) e.appendChild(typeof c === "string" ? document.createTextNode(c) : c); });
  return e;
}
function initials(name = "") { return name.split(" ").filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase(); }
function render() { const App = document.getElementById("app"); App.innerHTML = ""; App.appendChild(Screens[state.screen]()); }
function setScreen(name, extra = {}) { Object.assign(state, extra); state.screen = name; window.scrollTo(0, 0); render(); }
function navTo(name, extra) { screenStack.push(name); setScreen(name, extra); }
function goBack() { screenStack.pop(); setScreen(screenStack[screenStack.length - 1] || "home"); }
function toggleTheme() { state.theme = state.theme === "dark" ? "light" : "dark"; document.body.setAttribute("data-theme", state.theme); render(); }
function toggleFav(key, meta, e) { e.stopPropagation(); state.favorites.has(key) ? state.favorites.delete(key) : state.favorites.set(key, meta); render(); }
function FavStar(key, meta) { return el("div", { class: "fav-star", onclick: (e) => toggleFav(key, meta, e) }, state.favorites.has(key) ? "⭐" : "☆"); }

/* ---------- shared UI ---------- */
function TopBar({ back = false, title = null } = {}) {
  const bar = el("div", { class: "topbar" });
  if (back) {
    bar.className = "back-row";
    bar.appendChild(el("div", { class: "icon-btn", onclick: goBack }, "←"));
    bar.appendChild(el("div", { class: "brand-name" }, title || ""));
    return bar;
  }
  bar.appendChild(el("div", { class: "brand" }, [ el("img", { src: APP_LOGO, class: "brand-mark", style: "object-fit:cover;" }), el("div", { class: "brand-name" }, ["Cricket", el("span", {}, "Live"), " World"]) ]));
  bar.appendChild(el("div", { class: "topbar-actions" }, [
    el("div", { class: "icon-btn", onclick: toggleTheme }, state.theme === "dark" ? "☾" : "☀"),
    el("div", { class: "icon-btn", onclick: () => navTo("search") }, "🔍"),
  ]));
  return bar;
}
function BottomNav() {
  const items = [["home","🏠","Home"],["matches","🏏","Matches"],["series","🏆","Series"],["teams","🌍","Teams"],["more","⋯","More"]];
  const nav = el("div", { class: "bottom-nav" });
  items.forEach(([id, icon, label]) => {
    const active = state.screen === id || (id === "more" && ["favorites","settings","about","players","playerDetail"].includes(state.screen));
    nav.appendChild(el("div", { class: "nav-item" + (active ? " active" : ""), onclick: () => navTo(id) }, [ el("div", { class: "nav-icon" }, icon), el("div", {}, label) ]));
  });
  return nav;
}
function EmptyBlock(title, sub, icon = "🏏") {
  return el("div", { class: "state-block" }, [ el("div", { class: "state-icon" }, icon), el("div", { class: "state-title" }, title), el("div", { class: "state-sub" }, sub) ]);
}
function LoadingBlock(n = 3) {
  const wrap = el("div", { style: "display:flex; flex-direction:column; gap:12px;" });
  for (let i = 0; i < n; i++) wrap.appendChild(el("div", { class: "skeleton", style: "height:96px;" }));
  return wrap;
}
function ErrorBlock(err, onRetry) {
  let title = "Couldn't load this";
  let sub = "Something went wrong talking to the cricket data server.";
  let icon = "⚠";
  if (err && err.code === "NETWORK_ERROR") {
    title = "Can't reach the server";
    sub = "Check that the backend is running and CONFIG.API_BASE_URL in app.js points to it, then check your internet/Wi-Fi connection.";
    icon = "📡";
  } else if (err && err.code === "RATE_LIMIT") {
    title = "Rate limit reached";
    sub = "Too many requests to the cricket data provider right now. Please wait a moment and retry.";
    icon = "⏳";
  } else if (err && err.code === "BAD_RESPONSE") {
    title = "Server error";
    sub = err.info || "The backend returned an error. Check the backend's terminal/logs for details.";
    icon = "🛠";
  }
  return el("div", { class: "state-block" }, [
    el("div", { class: "state-icon" }, icon),
    el("div", { class: "state-title" }, title),
    el("div", { class: "state-sub" }, sub),
    onRetry ? el("button", { class: "retry-btn", onclick: onRetry }, "Retry") : null,
  ]);
}
function scoreStr(t) {
  if (!t) return "TBD";
  if (t.score == null) return "Yet to bat";
  return `${t.score}${t.wkts != null ? "/" + t.wkts : ""}${t.overs != null ? " (" + t.overs + ")" : ""}`;
}
function MatchCard(m, full = false) {
  const card = el("div", { class: "match-card" + (full ? " full" : ""), onclick: () => navTo("matchDetail", { activeMatchId: m.id, activeMatchTab: "overview" }) });
  card.appendChild(FavStar("match:" + m.id, { label: `${m.t1 ? m.t1.name : "?"} vs ${m.t2 ? m.t2.name : "?"}`, sub: m.series, screen: "matchDetail", params: { activeMatchId: m.id, activeMatchTab: "overview" } }));
  card.appendChild(el("div", { class: "match-card-top" }, [
    el("div", { class: "match-series" }, m.series),
    m.live ? el("div", { class: "live-tag" }, [el("div", { class: "live-dot" }), "Live"]) : el("div", { style: "font-size:10px;color:var(--ink-faint);font-weight:600;" }, m.matchType || ""),
  ]));
  [m.t1, m.t2].forEach(t => {
    card.appendChild(el("div", { class: "team-row" }, [
      el("div", { class: "team-info" }, [ el("div", { class: "team-flag" }, initials(t ? t.name : "??")), el("div", { class: "team-name" }, t ? t.name : "TBD") ]),
      el("div", { class: "team-score" }, scoreStr(t)),
    ]));
  });
  card.appendChild(el("div", { class: "match-status" }, m.status || "Status not available"));
  if (m.venue) card.appendChild(el("div", { class: "match-venue" }, m.venue));
  return card;
}

/* ============================================================
   SCREENS
   ============================================================ */
const Screens = {};

Screens.home = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar());
  wrap.appendChild(el("div", { class: "search-wrap", onclick: () => navTo("search") }, [ el("div", { class: "search-box" }, [ el("span", {}, "🔍"), el("input", { placeholder: "Search matches, teams, players, series", readonly: true }) ]) ]));

  const liveSec = el("div", { class: "section" }, [
    el("div", { class: "section-head" }, [ el("div", { class: "section-title" }, [el("div", { class: "live-dot" }), "Live Matches"]), el("div", { class: "section-link", onclick: () => navTo("matches", { matchStatus: "live" }) }, "See all") ]),
  ]);
  const liveHost = el("div", { class: "hscroll" }, [LoadingBlock(1)]);
  liveSec.appendChild(liveHost);

  const upSec = el("div", { class: "section" }, [
    el("div", { class: "section-head" }, [ el("div", { class: "section-title" }, "Upcoming Matches"), el("div", { class: "section-link", onclick: () => navTo("matches", { matchStatus: "upcoming" }) }, "See all") ]),
  ]);
  const upHost = el("div", { class: "hscroll" });
  upSec.appendChild(upHost);

  const resSec = el("div", { class: "section" }, [
    el("div", { class: "section-head" }, [ el("div", { class: "section-title" }, "Recent Results"), el("div", { class: "section-link", onclick: () => navTo("matches", { matchStatus: "completed" }) }, "See all") ]),
  ]);
  const resHost = el("div", {});
  resSec.appendChild(resHost);

  wrap.appendChild(liveSec); wrap.appendChild(el("div", { class: "seam" }));
  wrap.appendChild(upSec); wrap.appendChild(el("div", { class: "seam" }));
  wrap.appendChild(resSec);
  wrap.appendChild(BottomNav());

  function load() {
    liveHost.innerHTML = ""; liveHost.appendChild(LoadingBlock(1));
    CricketAPI.currentMatches()
      .then(res => {
        const all = (res.data || []).map(mapMatch);
        state.cache.home = all;
        const live = all.filter(m => m.matchStarted && !m.matchEnded);
        const upcoming = all.filter(m => !m.matchStarted).slice(0, 10);
        const completed = all.filter(m => m.matchEnded).slice(0, 6);

        liveHost.innerHTML = "";
        if (!live.length) liveHost.appendChild(EmptyBlock("No live matches right now", "Nothing is currently in progress according to the data provider.", "🏟"));
        else live.forEach(m => liveHost.appendChild(MatchCard(m)));

        upHost.innerHTML = "";
        if (!upcoming.length) upHost.appendChild(EmptyBlock("No upcoming matches listed", "The provider hasn't published upcoming fixtures right now.", "📅"));
        else upcoming.forEach(m => upHost.appendChild(MatchCard(m)));

        resHost.innerHTML = "";
        if (!completed.length) resHost.appendChild(EmptyBlock("No recent results", "Completed matches will show up here once available.", "🏁"));
        else completed.forEach(m => resHost.appendChild(MatchCard(m, true)));
      })
      .catch(err => {
        liveHost.innerHTML = ""; liveHost.appendChild(ErrorBlock(err, load));
        upHost.innerHTML = ""; resHost.innerHTML = "";
      });
  }
  load();
  return wrap;
};

Screens.matches = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar());
  wrap.appendChild(el("div", { class: "section", style: "padding-top:2px; padding-bottom:0;" }, [ el("div", { class: "section-title" }, "Matches") ]));

  const statusOptions = [["live","🔴 Live"],["upcoming","Upcoming"],["completed","Finished"],["all","All"]];
  const statusRow = el("div", { class: "status-col" });
  statusOptions.forEach(([id, label]) => statusRow.appendChild(el("div", { class: "status-btn" + (state.matchStatus === id ? " active" : ""), onclick: () => setScreen("matches", { matchStatus: id }) }, label)));
  wrap.appendChild(statusRow);

  const filters = [["all","All Formats"],["t20","T20"],["odi","ODI"],["test","Test"],["women","Women's"]];
  const chipRow = el("div", { class: "chip-row", style: "padding-top:12px;" });
  filters.forEach(([id, label]) => chipRow.appendChild(el("div", { class: "chip" + (state.matchFilter === id ? " active" : ""), onclick: () => setScreen("matches", { matchFilter: id }) }, label)));
  wrap.appendChild(chipRow);

  const host = el("div", { class: "section" }, [LoadingBlock(3)]);
  wrap.appendChild(host);
  wrap.appendChild(BottomNav());

  function load() {
    host.innerHTML = ""; host.appendChild(LoadingBlock(3));
    CricketAPI.currentMatches()
      .then(res => {
        let all = (res.data || []).map(mapMatch);
        if (state.matchFilter !== "all") {
          all = all.filter(m => state.matchFilter === "women" ? /women/i.test(m.series) : m.matchType.toLowerCase() === state.matchFilter);
        }
        const buckets = state.matchStatus === "all" ? all : all.filter(m => {
          if (state.matchStatus === "live") return m.matchStarted && !m.matchEnded;
          if (state.matchStatus === "upcoming") return !m.matchStarted;
          return m.matchEnded;
        });
        host.innerHTML = "";
        if (!buckets.length) { host.appendChild(EmptyBlock("No matches found", "Nothing matches this filter right now.", "🏏")); return; }
        buckets.forEach(m => host.appendChild(MatchCard(m, true)));
      })
      .catch(err => { host.innerHTML = ""; host.appendChild(ErrorBlock(err, load)); });
  }
  load();
  return wrap;
};

Screens.matchDetail = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar({ back: true, title: "Match" }));
  const heroHost = el("div", { class: "detail-hero" }, [LoadingBlock(1)]);
  wrap.appendChild(heroHost);

  const tabs = ["overview", "scorecard", "commentary", "stats"];
  const tabBar = el("div", { class: "tabs" });
  tabs.forEach(t => tabBar.appendChild(el("div", { class: "tab" + (state.activeMatchTab === t ? " active" : ""), onclick: () => setScreen("matchDetail", { activeMatchTab: t }) }, t[0].toUpperCase() + t.slice(1))));
  wrap.appendChild(tabBar);

  const panel = el("div", { class: "tab-panel" }, [LoadingBlock(2)]);
  wrap.appendChild(panel);
  wrap.appendChild(BottomNav());

  const id = state.activeMatchId;
  Promise.allSettled([CricketAPI.matchInfo(id), CricketAPI.matchScorecard(id)]).then(([infoRes, scoreRes]) => {
    const info = infoRes.status === "fulfilled" ? infoRes.value.data : null;
    const infoErr = infoRes.status === "rejected" ? infoRes.reason : null;
    const score = scoreRes.status === "fulfilled" ? scoreRes.value.data : null;

    heroHost.innerHTML = "";
    if (!info) { heroHost.appendChild(ErrorBlock(infoErr, () => setScreen("matchDetail"))); }
    else {
      const teams = info.teamInfo ? info.teamInfo.map(t => t.name) : (info.teams || []);
      heroHost.appendChild(el("div", {}, [
        el("div", { class: "match-series", style: "margin-bottom:6px;" }, info.name || ""),
        ...teams.map(name => {
          const sc = (info.score || []).find(s => s.inning && s.inning.startsWith(name));
          return el("div", { class: "detail-team" }, [
            el("div", { class: "team-info" }, [el("div", { class: "team-flag" }, initials(name)), el("div", { class: "team-name" }, name)]),
            el("div", {}, [el("div", { class: "detail-score" }, sc ? `${sc.r}/${sc.w}` : "—"), el("div", { class: "detail-oversline" }, sc ? `${sc.o} ov` : "Yet to bat")]),
          ]);
        }),
        el("div", { class: "detail-status-bar" }, info.status || "Status not available"),
      ]));
    }

    panel.innerHTML = "";
    if (state.activeMatchTab === "overview") panel.appendChild(OverviewTab(info, infoErr));
    else if (state.activeMatchTab === "scorecard") panel.appendChild(ScorecardTab(score, scoreRes.status === "rejected" ? scoreRes.reason : null));
    else if (state.activeMatchTab === "commentary") panel.appendChild(CommentaryTab());
    else panel.appendChild(StatsTab());
  });

  return wrap;
};

function OverviewTab(info, err) {
  if (!info) return ErrorBlock(err, () => setScreen("matchDetail"));
  const box = el("div", {});
  box.appendChild(el("div", { class: "sc-inning-title", style: "margin-top:0;" }, "Match Details"));
  const rows = [
    ["Venue", info.venue], ["Date", info.date],
    ["Match type", (info.matchType || "").toUpperCase() || null],
    ["Toss", info.toss ? `${info.toss.winner} won, chose to ${info.toss.decision}` : null],
    ["Status", info.status],
  ];
  rows.forEach(([label, val]) => {
    box.appendChild(el("div", { class: "settings-row" }, [
      el("div", { style: "font-size:12.5px; color:var(--ink-faint);" }, label),
      el("div", { style: "font-size:12.5px; font-weight:600; text-align:right; max-width:60%;" }, val || "Not provided"),
    ]));
  });
  return box;
}

function ScorecardTab(score, err) {
  if (!score) return ErrorBlock(err, () => setScreen("matchDetail"));
  const list = Array.isArray(score.scorecard) ? score.scorecard : (Array.isArray(score) ? score : []);
  if (!list.length) return EmptyBlock("Scorecard not available yet", "Batting and bowling figures will appear here once the provider publishes them for this match.", "📋");
  const box = el("div", {});
  list.forEach(inn => {
    box.appendChild(el("div", { class: "sc-inning-title", style: "margin-top:0;" }, inn.inning || "Innings"));
    const bat = el("table", { class: "sc-table" }, [el("tr", {}, [el("th",{},"Batter"),el("th",{class:"num"},"R"),el("th",{class:"num"},"B"),el("th",{class:"num"},"4s"),el("th",{class:"num"},"6s"),el("th",{class:"num"},"SR")])]);
    (inn.batting || inn.batsman || []).forEach(b => bat.appendChild(el("tr", {}, [
      el("td",{class:"name"}, b.batsman || b.name || "—"), el("td",{class:"num"}, String(b.r ?? b.runs ?? 0)), el("td",{class:"num"}, String(b.b ?? b.balls ?? 0)),
      el("td",{class:"num"}, String(b["4s"] ?? 0)), el("td",{class:"num"}, String(b["6s"] ?? 0)), el("td",{class:"num"}, String(b.sr ?? "—")),
    ])));
    box.appendChild(bat);
    const bowl = el("table", { class: "sc-table", style: "margin-top:10px;" }, [el("tr", {}, [el("th",{},"Bowler"),el("th",{class:"num"},"O"),el("th",{class:"num"},"R"),el("th",{class:"num"},"W"),el("th",{class:"num"},"Econ")])]);
    (inn.bowling || inn.bowler || []).forEach(b => bowl.appendChild(el("tr", {}, [
      el("td",{class:"name"}, b.bowler || b.name || "—"), el("td",{class:"num"}, String(b.o ?? b.overs ?? 0)), el("td",{class:"num"}, String(b.r ?? b.runs ?? 0)),
      el("td",{class:"num"}, String(b.w ?? b.wickets ?? 0)), el("td",{class:"num"}, String(b.eco ?? "—")),
    ])));
    box.appendChild(bowl);
    if (inn.extras) box.appendChild(el("div", { style: "font-size:11.5px; color:var(--ink-faint); margin-top:8px;" }, "Extras: " + (typeof inn.extras === "object" ? Object.entries(inn.extras).map(([k,v])=>`${k} ${v}`).join(", ") : inn.extras)));
  });
  return box;
}

function CommentaryTab() {
  return EmptyBlock("Ball-by-ball commentary not available", "The connected API plan doesn't include delivery-by-delivery commentary. This tab is wired up and will populate automatically if you upgrade to a provider/plan that includes it — no other changes needed.", "🎙");
}
function StatsTab() {
  return EmptyBlock("Advanced stats not available", "Run rate, required run rate and partnerships need a live ball-by-ball feed, which the current API plan doesn't provide. This tab will populate automatically once that data is available.", "📈");
}

Screens.series = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar());
  wrap.appendChild(el("div", { class: "section" }, [ el("div", { class: "section-title" }, "Series & Tournaments") ]));
  const host = el("div", { class: "section", style: "padding-top:0;" }, [LoadingBlock(4)]);
  wrap.appendChild(host);
  wrap.appendChild(BottomNav());

  CricketAPI.series()
    .then(res => {
      const list = res.data || [];
      host.innerHTML = "";
      if (!list.length) { host.appendChild(EmptyBlock("No series found", "The provider isn't returning any series right now.", "🏆")); return; }
      list.slice(0, 25).forEach(s => {
        const card = el("div", { class: "match-card full", onclick: () => navTo("seriesDetail", { activeSeriesId: s.id }) });
        card.appendChild(FavStar("series:" + s.id, { label: s.name, sub: "Series", screen: "seriesDetail", params: { activeSeriesId: s.id } }));
        card.appendChild(el("div", { style: "font-weight:700; font-size:13.5px; margin-bottom:6px; padding-right:20px;" }, s.name));
        card.appendChild(el("div", { style: "font-size:11.5px; color:var(--ink-faint);" }, `${s.startDate || "?"} → ${s.endDate || "?"} · ${s.matches ?? "—"} matches`));
        host.appendChild(card);
      });
    })
    .catch(err => { host.innerHTML = ""; host.appendChild(ErrorBlock(err, () => setScreen("series"))); });

  return wrap;
};

Screens.seriesDetail = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar({ back: true, title: "Series" }));
  const host = el("div", { class: "section", style: "padding-top:6px;" }, [LoadingBlock(4)]);
  wrap.appendChild(host);
  wrap.appendChild(BottomNav());

  CricketAPI.seriesInfo(state.activeSeriesId)
    .then(res => {
      const d = res.data || {};
      host.innerHTML = "";
      host.appendChild(el("div", { class: "sc-inning-title", style: "margin-top:0;" }, (d.info && d.info.name) || "Series"));
      const matches = (d.matchList || []).map(mapMatch);
      if (!matches.length) host.appendChild(EmptyBlock("No fixtures listed", "This series' schedule and results haven't been published by the provider yet.", "📅"));
      else matches.forEach(m => host.appendChild(MatchCard(m, true)));
    })
    .catch(err => { host.innerHTML = ""; host.appendChild(ErrorBlock(err, () => setScreen("seriesDetail"))); });

  return wrap;
};

Screens.teams = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar());
  wrap.appendChild(el("div", { class: "section" }, [ el("div", { class: "section-title" }, "Teams") ]));
  wrap.appendChild(el("div", { class: "search-wrap" }, [ el("div", { class: "search-box" }, [ el("span", {}, "🔍"), el("input", {
    placeholder: "Search a country/team…", value: state.teamSearchQuery,
    oninput: (e) => { state.teamSearchQuery = e.target.value; renderGrid(); },
  }) ]) ]));
  const host = el("div", { class: "section grid-2", style: "padding-top:0;" }, [LoadingBlock(1)]);
  wrap.appendChild(host);
  wrap.appendChild(BottomNav());

  function renderGrid() {
    const list = (state.cache.countries || []).filter(c => !state.teamSearchQuery || c.name.toLowerCase().includes(state.teamSearchQuery.toLowerCase()));
    host.innerHTML = ""; host.className = "section grid-2";
    if (!list.length) { host.appendChild(EmptyBlock("No teams found", "Try a different search term.", "🌍")); return; }
    list.slice(0, 60).forEach(c => {
      const card = el("div", { class: "mini-card", onclick: () => navTo("teamDetail", { activeTeamName: c.name }) });
      card.appendChild(FavStar("team:" + c.name, { label: c.name, sub: "Team", screen: "teamDetail", params: { activeTeamName: c.name } }));
      card.appendChild(el("div", { class: "avatar-circle" }, initials(c.name)));
      card.appendChild(el("div", { class: "mini-name" }, c.name));
      host.appendChild(card);
    });
  }

  CricketAPI.countries()
    .then(res => { state.cache.countries = res.data || []; renderGrid(); })
    .catch(err => { host.innerHTML = ""; host.className = "section"; host.appendChild(ErrorBlock(err, () => setScreen("teams"))); });

  return wrap;
};

Screens.teamDetail = function () {
  const name = state.activeTeamName;
  const wrap = el("div");
  wrap.appendChild(TopBar({ back: true, title: name || "Team" }));
  const host = el("div", { class: "section", style: "padding-top:10px;" });
  host.appendChild(el("div", { style: "display:flex; flex-direction:column; align-items:center; gap:10px; padding:6px 0 20px;" }, [
    el("div", { class: "avatar-circle", style: "width:72px;height:72px;font-size:20px;" }, initials(name || "")),
    el("div", { style: "font-family:var(--font-display); font-weight:700; font-size:17px;" }, name || ""),
  ]));
  host.appendChild(el("div", { class: "sc-inning-title", style: "margin-top:0;" }, "Fixtures & Results"));
  const listHost = el("div", {}, [LoadingBlock(2)]);
  host.appendChild(listHost);
  wrap.appendChild(host);
  wrap.appendChild(BottomNav());

  CricketAPI.currentMatches()
    .then(res => {
      const all = (res.data || []).map(mapMatch);
      const related = all.filter(m => (m.t1 && m.t1.name === name) || (m.t2 && m.t2.name === name));
      listHost.innerHTML = "";
      if (!related.length) listHost.appendChild(EmptyBlock("No current matches for this team", "The provider's current match list doesn't include this team right now.", "🏏"));
      else related.forEach(m => listHost.appendChild(MatchCard(m, true)));
    })
    .catch(err => { listHost.innerHTML = ""; listHost.appendChild(ErrorBlock(err, () => setScreen("teamDetail"))); });

  return wrap;
};

Screens.more = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar());
  wrap.appendChild(el("div", { class: "section" }, [ el("div", { class: "section-title" }, "More") ]));
  const items = [["players","🏏","Players","Search players and view career stats"],["favorites","⭐","Favorites","Teams, players, matches & series you follow"],["account","👤", state.user ? state.user.name : "Account", state.user ? "Manage your account" : "Create an account or log in"],["settings","⚙","Settings","Theme & notification preferences"],["about","ℹ","About","App info & data source"]];
  const list = el("div", { class: "section", style: "padding-top:0;" });
  items.forEach(([id, icon, label, sub]) => list.appendChild(el("div", { class: "match-card full", style: "display:flex; align-items:center; gap:14px;", onclick: () => navTo(id) }, [ el("div", { class: "avatar-circle", style: "width:40px;height:40px;font-size:16px;" }, icon), el("div", {}, [el("div", { style: "font-weight:700; font-size:13.5px;" }, label), el("div", { style: "font-size:11px; color:var(--ink-faint); margin-top:2px;" }, sub)]) ])));
  wrap.appendChild(list);
  wrap.appendChild(BottomNav());
  return wrap;
};

Screens.players = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar({ back: true, title: "Players" }));
  wrap.appendChild(el("div", { class: "search-wrap" }, [ el("div", { class: "search-box" }, [ el("span", {}, "🔍"), el("input", {
    placeholder: "Search a player name…", value: state.playerSearchQuery, autofocus: true,
    oninput: (e) => { state.playerSearchQuery = e.target.value; },
    onkeydown: (e) => { if (e.key === "Enter") runSearch(); },
  }) ]) ]));
  const host = el("div", { class: "section grid-2", style: "padding-top:0;" });
  wrap.appendChild(host);
  wrap.appendChild(BottomNav());

  function runSearch() {
    if (!state.playerSearchQuery.trim()) return;
    host.innerHTML = ""; host.className = "section"; host.appendChild(LoadingBlock(1));
    CricketAPI.players(state.playerSearchQuery)
      .then(res => {
        const list = res.data || [];
        host.innerHTML = ""; host.className = "section grid-2";
        if (!list.length) { host.appendChild(EmptyBlock("No players found", "Try a different spelling or full name.", "🔎")); return; }
        list.slice(0, 20).forEach(p => {
          const card = el("div", { class: "mini-card", onclick: () => navTo("playerDetail", { activePlayerId: p.id }) });
          card.appendChild(FavStar("player:" + p.id, { label: p.name, sub: p.country || "Player", screen: "playerDetail", params: { activePlayerId: p.id } }));
          card.appendChild(el("div", { class: "avatar-circle" }, initials(p.name)));
          card.appendChild(el("div", { class: "mini-name" }, p.name));
          card.appendChild(el("div", { class: "mini-sub" }, p.country || ""));
          host.appendChild(card);
        });
      })
      .catch(err => { host.innerHTML = ""; host.className = "section"; host.appendChild(ErrorBlock(err, runSearch)); });
  }
  host.appendChild(EmptyBlock("Search for a player", "Type a name above and press Enter to look up real profiles and stats.", "🏏"));
  return wrap;
};

Screens.playerDetail = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar({ back: true, title: "Player" }));
  const host = el("div", { class: "section", style: "padding-top:10px;" }, [LoadingBlock(2)]);
  wrap.appendChild(host);
  wrap.appendChild(BottomNav());

  CricketAPI.playerInfo(state.activePlayerId)
    .then(res => {
      const p = res.data || {};
      host.innerHTML = "";
      host.appendChild(el("div", { style: "display:flex; flex-direction:column; align-items:center; gap:10px; padding:6px 0 20px;" }, [
        el("div", { class: "avatar-circle", style: "width:72px;height:72px;font-size:22px;" }, initials(p.name || "")),
        el("div", { style: "font-family:var(--font-display); font-weight:700; font-size:17px;" }, p.name || "Unknown"),
        el("div", { style: "font-size:12px; color:var(--ink-faint);" }, [p.country, p.role].filter(Boolean).join(" · ")),
      ]));
      [["Batting style", p.battingStyle], ["Bowling style", p.bowlingStyle], ["Date of birth", p.dateOfBirth], ["Place of birth", p.placeOfBirth]].forEach(([label, val]) => {
        host.appendChild(el("div", { class: "settings-row" }, [ el("div", { style: "font-size:12.5px; color:var(--ink-faint);" }, label), el("div", { style: "font-size:12.5px; font-weight:600;" }, val || "Not provided") ]));
      });
      host.appendChild(el("div", { class: "sc-inning-title" }, "Career Statistics"));
      if (p.stats && p.stats.length) {
        const table = el("table", { class: "sc-table" }, [el("tr", {}, [el("th",{},"Format"),el("th",{class:"num"},"Bat Avg"),el("th",{class:"num"},"Bowl Avg")])]);
        p.stats.forEach(s => table.appendChild(el("tr", {}, [el("td",{class:"name"},s.matchtype||"—"), el("td",{class:"num"}, s.battingAvg||"—"), el("td",{class:"num"}, s.bowlingAvg||"—")])));
        host.appendChild(table);
      } else host.appendChild(EmptyBlock("Stats not published", "This player's career statistics aren't available from the provider yet.", "📊"));
    })
    .catch(err => { host.innerHTML = ""; host.appendChild(ErrorBlock(err, () => setScreen("playerDetail"))); });

  return wrap;
};

Screens.search = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar({ back: true, title: "Search" }));
  wrap.appendChild(el("div", { class: "search-wrap" }, [ el("div", { class: "search-box" }, [ el("span", {}, "🔍"), el("input", {
    placeholder: "Search teams, players, series", value: state.searchQuery, autofocus: true,
    oninput: (e) => { state.searchQuery = e.target.value; },
    onkeydown: (e) => { if (e.key === "Enter") runSearch(); },
  }) ]) ]));
  const host = el("div", { class: "section", style: "padding-top:0;" });
  wrap.appendChild(host);
  wrap.appendChild(BottomNav());

  function runSearch() {
    if (!state.searchQuery.trim()) return;
    host.innerHTML = ""; host.appendChild(LoadingBlock(2));
    Promise.allSettled([CricketAPI.series(state.searchQuery), CricketAPI.players(state.searchQuery)])
      .then(([seriesRes, playersRes]) => {
        host.innerHTML = "";
        const seriesList = seriesRes.status === "fulfilled" ? (seriesRes.value.data || []) : [];
        const playersList = playersRes.status === "fulfilled" ? (playersRes.value.data || []) : [];
        if (!seriesList.length && !playersList.length) { host.appendChild(EmptyBlock("No results", `Nothing matched "${state.searchQuery}".`, "🔎")); return; }
        if (seriesList.length) {
          host.appendChild(el("div", { class: "sc-inning-title", style: "margin-top:4px;" }, "Series"));
          seriesList.slice(0, 6).forEach(s => host.appendChild(el("div", { class: "match-card full", onclick: () => navTo("seriesDetail", { activeSeriesId: s.id }) }, [el("div", { style: "font-weight:700; font-size:13px;" }, s.name)])));
        }
        if (playersList.length) {
          host.appendChild(el("div", { class: "sc-inning-title" }, "Players"));
          host.appendChild(el("div", { class: "grid-2" }, playersList.slice(0, 6).map(p => el("div", { class: "mini-card", onclick: () => navTo("playerDetail", { activePlayerId: p.id }) }, [el("div", { class: "avatar-circle" }, initials(p.name)), el("div", { class: "mini-name" }, p.name)]))));
        }
      })
      .catch(err => { host.innerHTML = ""; host.appendChild(ErrorBlock(err, runSearch)); });
  }
  host.appendChild(EmptyBlock("Search CricketLive World", "Find real teams, players and series from the connected data provider.", "🔍"));
  return wrap;
};

Screens.favorites = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar({ back: true, title: "Favorites" }));
  const host = el("div", { class: "section", style: "padding-top:6px;" });
  if (!state.favorites.size) {
    host.appendChild(EmptyBlock("No favorites yet", "Tap the star ☆ on any match, team, player or series to follow it here.", "⭐"));
  } else {
    [...state.favorites.entries()].forEach(([key, meta]) => {
      const card = el("div", { class: "match-card full", style: "position:relative;", onclick: () => navTo(meta.screen, meta.params) });
      card.appendChild(el("div", { style: "font-weight:700; font-size:13px;" }, meta.label));
      if (meta.sub) card.appendChild(el("div", { style: "font-size:11px; color:var(--ink-faint); margin-top:3px;" }, meta.sub));
      host.appendChild(card);
    });
  }
  wrap.appendChild(host);
  wrap.appendChild(BottomNav());
  return wrap;
};

Screens.account = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar({ back: true, title: "Account" }));
  const host = el("div", { class: "section", style: "padding-top:6px;" });

  if (state.user) {
    host.appendChild(el("div", { style: "display:flex; flex-direction:column; align-items:center; gap:10px; padding:10px 0 22px;" }, [
      el("div", { class: "avatar-circle", style: "width:72px;height:72px;font-size:22px;" }, initials(state.user.name)),
      el("div", { style: "font-family:var(--font-display); font-weight:700; font-size:17px;" }, state.user.name),
      el("div", { style: "font-size:12px; color:var(--ink-faint);" }, state.user.email),
    ]));
    host.appendChild(el("div", { class: "settings-row" }, [ el("div", { style: "font-size:12.5px; color:var(--ink-faint);" }, "Favorites saved"), el("div", { style: "font-size:12.5px; font-weight:700; color:var(--gold);" }, String(state.favorites.size)) ]));
    host.appendChild(el("button", { class: "retry-btn", style: "width:100%; margin-top:20px;", onclick: () => { state.user = null; setScreen("account"); } }, "Log out"));
    host.appendChild(el("div", { class: "config-note" }, "This is a demo account stored only for this session — nothing is sent to a server yet. Real sign-up will sync here once a backend auth endpoint is connected."));
  } else {
    const tabRow = el("div", { class: "tabs", style: "margin:0 0 16px;" });
    ["login", "signup"].forEach(mode => tabRow.appendChild(el("div", { class: "tab" + (state.authMode === mode ? " active" : ""), onclick: () => setScreen("account", { authMode: mode, authError: "" }) }, mode === "login" ? "Log In" : "Sign Up")));
    host.appendChild(tabRow);
    const nameField = state.authMode === "signup" ? el("div", { class: "search-box", style: "margin-bottom:10px;" }, [ el("span", {}, "👤"), el("input", { id: "acc-name", placeholder: "Full name" }) ]) : null;
    const emailField = el("div", { class: "search-box", style: "margin-bottom:10px;" }, [ el("span", {}, "✉"), el("input", { id: "acc-email", type: "email", placeholder: "Email address" }) ]);
    const passField = el("div", { class: "search-box", style: "margin-bottom:6px;" }, [ el("span", {}, "🔒"), el("input", { id: "acc-pass", type: "password", placeholder: "Password" }) ]);
    if (nameField) host.appendChild(nameField);
    host.appendChild(emailField); host.appendChild(passField);
    if (state.authError) host.appendChild(el("div", { style: "color:var(--wicket); font-size:11.5px; font-weight:600; margin:6px 0;" }, state.authError));
    host.appendChild(el("button", {
      class: "retry-btn", style: "width:100%; margin-top:14px; padding:12px;",
      onclick: () => {
        const email = document.getElementById("acc-email").value.trim();
        const pass = document.getElementById("acc-pass").value.trim();
        const name = state.authMode === "signup" ? document.getElementById("acc-name").value.trim() : email.split("@")[0];
        if (!email || !pass || (state.authMode === "signup" && !name)) { setScreen("account", { authError: "Please fill in all fields." }); return; }
        if (!email.includes("@")) { setScreen("account", { authError: "Enter a valid email address." }); return; }
        state.user = { name: name || "Cricket Fan", email };
        setScreen("account", { authError: "" });
      },
    }, state.authMode === "signup" ? "Create Account" : "Log In"));
    host.appendChild(el("div", { style: "text-align:center; margin:18px 0; color:var(--ink-faint); font-size:11px;" }, "— or —"));
    host.appendChild(el("button", { class: "chip", style: "width:100%; justify-content:center; display:flex; padding:12px; font-size:12.5px;", onclick: () => setScreen("more") }, "Continue as Guest"));
    host.appendChild(el("div", { class: "config-note" }, "Demo sign-up — accounts are kept only for this session in memory, not sent anywhere. A real backend with secure auth can be wired in behind this same screen."));
  }
  wrap.appendChild(host);
  wrap.appendChild(BottomNav());
  return wrap;
};

Screens.settings = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar({ back: true, title: "Settings" }));
  const host = el("div", { class: "section", style: "padding-top:6px;" });
  const themeRow = el("div", { class: "settings-row" }, [ el("div", {}, [el("div", { style: "font-weight:600; font-size:13px;" }, "Dark mode"), el("div", { style: "font-size:11px; color:var(--ink-faint);" }, "Switch between light and dark theme")]) ]);
  themeRow.appendChild(el("div", { class: "toggle" + (state.theme === "dark" ? " on" : ""), onclick: toggleTheme }, [el("div", { class: "knob" })]));
  host.appendChild(themeRow);
  [["Match started","Notify when a favorited match begins"],["Wicket alerts","Notify on every wicket in followed matches"],["Fifty / Century","Milestone alerts for followed players"]].forEach(([label, sub]) => {
    host.appendChild(el("div", { class: "settings-row" }, [ el("div", {}, [el("div", { style: "font-weight:600; font-size:13px;" }, label), el("div", { style: "font-size:11px; color:var(--ink-faint);" }, sub)]), el("div", { class: "toggle", style: "opacity:0.4;" }, [el("div", { class: "knob" })]) ]));
  });
  host.appendChild(el("div", { class: "config-note" }, "Notifications require a push service (e.g. Firebase Cloud Messaging) wired to real match events from the backend — toggles are disabled here until that's connected."));
  wrap.appendChild(host);
  wrap.appendChild(BottomNav());
  return wrap;
};

Screens.about = function () {
  const wrap = el("div");
  wrap.appendChild(TopBar({ back: true, title: "About" }));
  const host = el("div", { class: "section", style: "padding-top:6px; line-height:1.7; font-size:12.5px; color:var(--ink-dim);" });
  host.appendChild(el("div", { style: "font-family:var(--font-display); font-weight:700; font-size:16px; color:var(--ink); margin-bottom:10px;" }, "CricketLive World"));
  host.appendChild(el("p", {}, "A fast, mobile-first cricket companion for live scores, schedules, teams, players and series."));
  host.appendChild(el("div", { class: "sc-inning-title" }, "Data source"));
  host.appendChild(el("p", {}, "All match, team, player and series data shown in this app is fetched live from a cricket data provider through this app's own backend — nothing here is invented or hardcoded. If a screen shows \"not available,\" that's the provider's plan not including that data yet, not a placeholder."));
  host.appendChild(el("div", { class: "sc-inning-title" }, "Version"));
  host.appendChild(el("p", {}, "1.0.0"));
  wrap.appendChild(host);
  wrap.appendChild(BottomNav());
  return wrap;
};

render();
