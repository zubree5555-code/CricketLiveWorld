# Deploying CricketLive World on Vercel

I can't run the actual `vercel deploy` command from here — I don't have a
connected Vercel account or network access to Vercel's servers in this
environment, and the only Vercel tool available to me is read-only
(listing/inspecting existing projects, not creating deployments). So this
is the exact path to do it yourself; it's a few steps.

## What changed for Vercel

Your original `server/` folder is a normal Express server, which needs a
process that stays running — Vercel doesn't work that way, it runs
short-lived serverless functions instead. So I added an `/api` folder at
the project root: one small file per endpoint, each a Vercel serverless
function. It's the same proxy logic (same caching, same rate-limiting,
same "never expose the key" rule) just reshaped to fit Vercel's model.

```
CricketLiveWorld/
├── api/                     ← NEW — this is what runs on Vercel
│   ├── _lib/proxy.js        (shared logic: calls CricAPI, caches, rate-limits)
│   ├── health.js
│   ├── current-matches.js
│   ├── match-info.js
│   ├── match-scorecard.js
│   ├── series.js
│   ├── series-info.js
│   ├── players.js
│   ├── players-info.js
│   └── countries.js
├── vercel.json              ← NEW — tells Vercel where the static site lives
├── www/                     ← unchanged, this is your frontend
└── server/                  ← unchanged, kept as an alternative if you
                                ever want to host the backend somewhere
                                that isn't serverless (Render, a VPS, etc.)
```

`www/js/app.js`'s `CONFIG.API_BASE_URL` is now `"/api"` — a relative path,
since on Vercel your frontend and your API live on the same domain. You
don't need to edit this for the Vercel deploy to work.

## 1. Set up a Vercel account (if you don't have one)

https://vercel.com/signup — free tier is enough for this project.

## 2. Deploy — pick one path

### Option A: Vercel CLI (fastest, no GitHub needed)
```bash
npm install -g vercel
cd CricketLiveWorld
vercel login
vercel
```
It'll ask a few setup questions — accept the defaults (it auto-detects
`vercel.json`). This creates a preview deployment. When you're ready for
your real URL:
```bash
vercel --prod
```

### Option B: GitHub + Vercel dashboard (better for ongoing updates)
1. Push this project to a GitHub repo.
2. Go to https://vercel.com/new, import that repo.
3. Vercel reads `vercel.json` automatically — no build command needed,
   just click **Deploy**.

## 3. Add your API key — in the Vercel dashboard, not in code

This is the one manual step that matters most:

1. Open your project on vercel.com → **Settings → Environment Variables**.
2. Add:
   - **Name:** `CRICKET_API_KEY`
   - **Value:** your real key from https://cricapi.com/
   - **Environment:** Production (and Preview, if you want preview
     deployments to also have live data)
3. Redeploy (Vercel → Deployments → ⋯ → Redeploy) so the functions pick up
   the new variable — env var changes don't apply to deployments that
   already ran.

The key never appears in your repo, in `www/js/app.js`, or in anything
sent to the browser — it only exists inside `process.env` on Vercel's
servers, read by the functions in `/api`.

## 4. Test the live deployment

Once deployed, Vercel gives you a URL like
`https://cricketlive-world.vercel.app`. Test the API directly first:

```bash
curl https://cricketlive-world.vercel.app/api/health
# → {"ok":true,"keyConfigured":true}

curl https://cricketlive-world.vercel.app/api/current-matches
```

If `keyConfigured` is `false`, the environment variable isn't set (or
you deployed before adding it — redeploy). Then open the URL itself in a
browser — Home should show real matches or an honest empty state.

## 5. Point the Android app at this deployment

In `www/js/app.js`, `CONFIG.API_BASE_URL` is already `"/api"`, which is
correct for the web deployment but **won't resolve inside the packaged
Android app** (there's no same-origin `/api` on the phone). Before
building the APK/AAB, change it to your full Vercel URL:

```js
const CONFIG = {
  API_BASE_URL: "https://cricketlive-world.vercel.app/api",
  ...
};
```
Then `npx cap sync` and rebuild in Android Studio, as covered in
`ANDROID_READINESS.md`.
